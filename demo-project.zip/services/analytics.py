"""
Analytics module providing technical indicators, portfolio metrics, and simulations.
"""

import numpy as np
import pandas as pd


def calculate_moving_averages(series: pd.Series, short_window: int = 20, long_window: int = 50):
    """
    Computes short-term and long-term simple moving averages for a given price series.
    """
    short_sma = series.rolling(window=short_window, min_periods=1).mean()
    long_sma = series.rolling(window=long_window, min_periods=1).mean()
    return short_sma, long_sma


def compute_rsi(series: pd.Series, period: int = 14) -> pd.Series:
    """
    Computes Relative Strength Index (RSI) oscillating between 0 and 100.
    """
    delta = series.diff()
    gain = delta.where(delta > 0, 0.0)
    loss = -delta.where(delta < 0, 0.0)

    avg_gain = gain.rolling(window=period, min_periods=period).mean()
    avg_loss = loss.rolling(window=period, min_periods=period).mean()

    rs = avg_gain / (avg_loss + 1e-9)
    rsi = 100 - (100 / (1 + rs))
    return rsi.fillna(50.0)


def calculate_sharpe_ratio(returns: pd.Series, risk_free_rate: float = 0.04) -> float:
    """
    Calculates the annualized Sharpe Ratio for an investment asset or portfolio.
    """
    excess_returns = returns - (risk_free_rate / 252.0)
    std = returns.std()
    if std == 0 or np.isnan(std):
        return 0.0
    return float((excess_returns.mean() / std) * np.sqrt(252))


def calculate_portfolio_drawdown(nav_series: pd.Series) -> pd.Series:
    """
    Calculates the running drawdown series from peak net asset value.
    """
    rolling_max = nav_series.cummax()
    drawdown = (nav_series - rolling_max) / rolling_max
    return drawdown


def monte_carlo_simulation(
    initial_price: float, mu: float, sigma: float, days: int = 252, simulations: int = 500
) -> pd.DataFrame:
    """
    Runs Geometric Brownian Motion (GBM) Monte Carlo simulations.
    """
    dt = 1.0 / days
    simulated_paths = np.zeros((days, simulations))
    simulated_paths[0] = initial_price

    drift = (mu - 0.5 * sigma**2) * dt
    shock = sigma * np.sqrt(dt)

    for t in range(1, days):
        z = np.random.standard_normal(simulations)
        simulated_paths[t] = simulated_paths[t - 1] * np.exp(drift + shock * z)

    return pd.DataFrame(simulated_paths)
