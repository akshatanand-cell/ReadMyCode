"""
Data loading and synthesis utilities for financial time-series.
"""

import numpy as np
import pandas as pd


def generate_synthetic_quotes(tickers: list, days: int = 365) -> pd.DataFrame:
    """
    Generates realistic geometric random walk historical prices for selected tickers.
    """
    np.random.seed(42)
    dates = pd.date_range(end=pd.Timestamp.now(), periods=days, freq="B")
    data = {}

    base_prices = {
        "AAPL": 180.0,
        "NVDA": 130.0,
        "MSFT": 420.0,
        "GOOGL": 175.0,
        "AMZN": 185.0,
        "TSLA": 250.0,
    }

    for ticker in tickers:
        p0 = base_prices.get(ticker, 100.0)
        daily_volatility = np.random.uniform(0.012, 0.024)
        daily_drift = 0.0004
        daily_returns = np.random.normal(daily_drift, daily_volatility, days)
        price_series = p0 * np.exp(np.cumsum(daily_returns))
        data[ticker] = price_series

    return pd.DataFrame(data, index=dates)


def clean_financial_series(df: pd.DataFrame) -> pd.DataFrame:
    """
    Cleanses NaN, infinite values, and forward-fills missing market bars.
    """
    clean_df = df.replace([np.inf, -np.inf], np.nan)
    clean_df = clean_df.ffill().bfill()
    return clean_df


def calculate_log_returns(price_df: pd.DataFrame) -> pd.DataFrame:
    """
    Computes natural logarithmic returns for multi-asset price DataFrames.
    """
    return np.log(price_df / price_df.shift(1)).dropna()
