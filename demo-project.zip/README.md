# MarketPulse AI — Intelligent Portfolio & Technical Analysis Engine

MarketPulse AI is an enterprise-grade quantitative analytics and financial intelligence platform built with Python, Streamlit, and Plotly.

## Features
- **Technical Indicators**: Moving Averages (SMA 20/50), 14-day RSI oscillators with overbought/oversold detection.
- **Modern Portfolio Theory**: Asset allocation weighting, expected annualized returns, Sharpe ratio, and drawdown tracking.
- **Monte Carlo Simulations**: Geometric Brownian Motion (GBM) projecting 252-day forward-looking return distributions.
- **Interactive UI**: Real-time dark mode charts and interactive parameter controls.

## Quickstart

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deployment
Deploy to Streamlit Community Cloud in 1 click with `app.py` as the main module.
