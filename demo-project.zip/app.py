"""
MarketPulse AI - Intelligent Portfolio & Technical Analysis Engine
Built with Streamlit, Plotly, Pandas, and NumPy.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from services.data_loader import generate_synthetic_quotes, calculate_log_returns
from services.analytics import (
    calculate_moving_averages,
    compute_rsi,
    calculate_sharpe_ratio,
    monte_carlo_simulation,
    calculate_portfolio_drawdown,
)
from models.portfolio import Portfolio, Asset

st.set_page_config(
    page_title="MarketPulse AI",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.title("📈 MarketPulse AI — Quantitative Portfolio Intelligence")
st.markdown("Analyze equity performance, compute technical indicators, and simulate risk.")

# Sidebar Configuration
st.sidebar.header("Configuration")
selected_tickers = st.sidebar.multiselect(
    "Select Tickers",
    options=["AAPL", "NVDA", "MSFT", "GOOGL", "AMZN", "TSLA"],
    default=["AAPL", "NVDA", "MSFT"],
)
days_history = st.sidebar.slider("Historical Lookback (Days)", min_value=60, max_value=730, value=365)
risk_free_rate = st.sidebar.number_input("Risk Free Rate (Annual %)", value=4.5) / 100.0

if not selected_tickers:
    st.warning("Please select at least one ticker from the sidebar.")
    st.stop()

# Generate and Load Data
with st.spinner("Generating financial market data..."):
    df_prices = generate_synthetic_quotes(selected_tickers, days=days_history)
    df_returns = calculate_log_returns(df_prices)

tab1, tab2, tab3 = st.tabs(["📊 Technical Analysis", "💼 Portfolio Allocation", "🎲 Monte Carlo Risk"])

with tab1:
    ticker = st.selectbox("Select Asset for Indicator Breakdown", selected_tickers)
    prices = df_prices[ticker]
    sma_20, sma_50 = calculate_moving_averages(prices, 20, 50)
    rsi_14 = compute_rsi(prices, 14)

    col1, col2, col3 = st.columns(3)
    curr_p = prices.iloc[-1]
    prev_p = prices.iloc[-2]
    pct_chg = ((curr_p / prev_p) - 1.0) * 100
    col1.metric("Current Price", f"${curr_p:.2f}", f"{pct_chg:+.2f}%")
    col2.metric("20-Day SMA", f"${sma_20.iloc[-1]:.2f}")
    rsi_val = rsi_14.iloc[-1]
    status_rsi = "Neutral" if 30 <= rsi_val <= 70 else ("Overbought" if rsi_val > 70 else "Oversold")
    col3.metric("RSI (14-Day)", f"{rsi_val:.1f}", status_rsi)

    fig = go.Figure()
    fig.add_trace(go.Scatter(x=df_prices.index, y=prices, mode="lines", name=f"{ticker} Price", line=dict(color="#3b82f6", width=2)))
    fig.add_trace(go.Scatter(x=df_prices.index, y=sma_20, mode="lines", name="SMA 20", line=dict(color="#f59e0b", dash="dash")))
    fig.add_trace(go.Scatter(x=df_prices.index, y=sma_50, mode="lines", name="SMA 50", line=dict(color="#ef4444", dash="dot")))
    fig.update_layout(title=f"{ticker} Price & Trend Moving Averages", template="plotly_dark", height=450)
    st.plotly_chart(fig, use_container_width=True)

with tab2:
    st.subheader("Asset Weight Optimization")
    weights = [1.0 / len(selected_tickers)] * len(selected_tickers)
    assets = [Asset(ticker=t, weight=w, expected_return=float(df_returns[t].mean() * 252), volatility=float(df_returns[t].std() * np.sqrt(252))) for t, w in zip(selected_tickers, weights)]
    portfolio = Portfolio(assets=assets)

    p_return = portfolio.get_portfolio_return()
    p_vol = portfolio.get_portfolio_volatility()
    p_sharpe = calculate_sharpe_ratio(df_returns.mean(axis=1), risk_free_rate=risk_free_rate)

    m1, m2, m3 = st.columns(3)
    m1.metric("Expected Annual Return", f"{p_return * 100:.2f}%")
    m2.metric("Annual Volatility", f"{p_vol * 100:.2f}%")
    m3.metric("Annualized Sharpe Ratio", f"{p_sharpe:.2f}")

    portfolio_equity = (1 + df_returns.mean(axis=1)).cumprod() * 10000
    drawdown = calculate_portfolio_drawdown(portfolio_equity)
    st.line_chart(portfolio_equity, height=300)

with tab3:
    st.subheader("Monte Carlo Path Simulation (252 Days Ahead)")
    sim_asset = selected_tickers[0]
    initial_p = df_prices[sim_asset].iloc[-1]
    asset_mu = df_returns[sim_asset].mean() * 252
    asset_sigma = df_returns[sim_asset].std() * np.sqrt(252)

    sim_paths = monte_carlo_simulation(initial_p, asset_mu, asset_sigma, days=252, simulations=200)
    fig_sim = go.Figure()
    for col in sim_paths.columns[:25]:
        fig_sim.add_trace(go.Scatter(y=sim_paths[col], mode="lines", line=dict(width=1), opacity=0.35, showlegend=False))
    fig_sim.update_layout(title=f"200 Simulated Price Paths for {sim_asset}", template="plotly_dark", height=450)
    st.plotly_chart(fig_sim, use_container_width=True)
