"""
Domain models representing investment assets and multi-asset portfolios.
"""

from typing import List
import numpy as np


class Asset:
    """
    Represents an individual financial security with weights and statistical metrics.
    """

    def __init__(self, ticker: str, weight: float, expected_return: float, volatility: float):
        self.ticker = ticker
        self.weight = weight
        self.expected_return = expected_return
        self.volatility = volatility

    def to_dict(self):
        return {
            "ticker": self.ticker,
            "weight": self.weight,
            "expected_return": self.expected_return,
            "volatility": self.volatility,
        }


class Portfolio:
    """
    Represents a weighted portfolio of assets and computes combined risk-return metrics.
    """

    def __init__(self, assets: List[Asset]):
        self.assets = assets

    def get_portfolio_return(self) -> float:
        """
        Computes weighted expected portfolio annual return.
        """
        return sum(asset.weight * asset.expected_return for asset in self.assets)

    def get_portfolio_volatility(self) -> float:
        """
        Approximates combined portfolio annualized volatility.
        """
        weighted_vars = sum((asset.weight * asset.volatility) ** 2 for asset in self.assets)
        return float(np.sqrt(weighted_vars))

    def rebalance_weights(self, new_weights: dict):
        """
        Reallocates asset weights based on target percentages.
        """
        for asset in self.assets:
            if asset.ticker in new_weights:
                asset.weight = new_weights[asset.ticker]
